from core import custom_queue

q = custom_queue.msgQueue()
q.make_conn()
<<<<<<< HEAD
weibo = q.get_new_wb('weibo')
print(weibo.decode())
# count = q.get_new_wb_count('weibo')
# print(count)
=======
# weibo = q.get_new_wb('weibo')
# print(weibo.decode())
count = q.get_new_wb_count('weibo')
print(count)


>>>>>>> 479f260ccdbf7a2204daf60ce9eb46a45026824b
